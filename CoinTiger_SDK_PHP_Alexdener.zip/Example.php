<?php

require_once (dirname(__FILE__) . '/CoinTiger/CoinTiger.php');

const API_KEY = "your api_key";
const SECRET_KEY = "your secret_key";

try {

	//CoinTiger DEMO 入口
	$client = new CoinTiger(new CoinTiger_ApiKeyAuthentication(API_KEY, SECRET_KEY));

	//前24小时行情
    $params = [
        'symbol' => 'tchbtc'
    ];
    $result = $client -> tickerDetailApi($params);
    print_r($result);

	//获取CoinTiger行情（盘口数据）
	$params = [
	    'symbol' => 'tchbtc',
        'type'   => 'step0'
    ];
	$result = $client -> tickerApi($params);
	print_r($result);

	//K线历史数据
	$params = [
	    'symbol' => 'tchbtc',
        'period' => '60min',
        'size'   => 150
    ];
	$result = $client -> klineDataApi($params);
	print_r($result);

	//获取CoinTiger成交历史数据
	$params = [
	    'symbol' => 'tchbtc',
        'size' => 5
    ];
	$result = $client -> tradesApi($params);
	print_r($result);

	//获取CoinTiger系统当前时间
	$result = $client->timestampApi();
	print_r($result);

    //查询cointiger站支持的所有币种
    $result = $client->currencysApi();
    print_r($result);

    //查询当前委托、历史委托
    $params = [
        'api_key'=> API_KEY,
        'symbol' => 'btcbitcny',
        'types'  => 'buy-limit',
        'states' => 'filled',
        'time'   => time() * 1000
    ];
    $result = $client -> ordersInfoApi($params);
    print_r($result);

    //查询当前成交、历史成交
    $params = [
        'api_key'    => API_KEY,
        'symbol'     => 'btcbitcny',
        'start-date' => '2018-07-01',
        'end-date'   => '2018-07-05',
        'time'   => time() * 1000
    ];
    $result = $client -> orderHistoryApi($params);
    print_r($result);

} catch (Exception $e) {
	$msg = $e -> getMessage();
	error_log($msg);
}
