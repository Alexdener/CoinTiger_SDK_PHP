<?php
require_once (dirname(__FILE__) . '/Base.php');

class CoinTiger extends CoinTigerBase {

    private $_marketMacro = CoinTigerBase::WEB_BASE . CoinTigerBase::MARKET_MACRO;
    private $_tradingMacroV2 = CoinTigerBase::WEB_BASE . CoinTigerBase::TRADING_MACRO_V2;

	//构造函数
	function __construct($authentication) {
		parent::__construct($authentication);
	}

	//前24小时行情
	public function tickerDetailApi($params = null) {
        return $this -> get($this->_marketMacro . 'detail', $params);
    }

	//获取CoinTiger行情（盘口数据）
	public function tickerApi($params = null) {
		return $this -> get($this->_marketMacro . 'depth', $params);
	}
	
	//获取CoinTiger系统当前时间
	public function timestampApi() {
		return $this -> get($this->_tradingMacroV2 . 'timestamp');
	}

	//查询cointiger站支持的所有币种
    public function currencysApi() {
        return $this -> get($this->_tradingMacroV2 . 'currencys');
    }

	//获取CoinTiger成交历史数据
	public function tradesApi($params = null) {
		return $this -> get($this->_marketMacro . 'history/trade', $params);
	}

	//K线数据
	public function klineDataApi($params = null) {
		return $this -> get($this->_marketMacro . 'history/kline', $params);
	}

	//查询当前委托、历史委托
	public function ordersInfoApi($params = null) {
		return $this -> getWithSign($this->_tradingMacroV2 . 'order/orders', $params);
	}

	//查询当前成交、历史成交
	public function orderHistoryApi($params = null) {
		return $this -> getWithSign($this->_tradingMacroV2 . 'order/match_results', $params);
	}

}
