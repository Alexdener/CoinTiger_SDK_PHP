<?php

abstract class CoinTiger_Authentication {
	
	//获取成员变量
	abstract public function getData();
}
