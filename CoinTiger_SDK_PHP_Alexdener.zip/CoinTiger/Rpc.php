<?php

class CoinTiger_Rpc {
	private $_requestor;
	private $authentication;

	public function __construct($requestor, $authentication) {
		$this -> _requestor = $requestor;
		$this -> _authentication = $authentication;
	}

	public function request($method, $url, $params) {
		// $url = CoinTigerBase::API_BASE . $url;
		// Initialize CURL
		$ch = curl_init();
		// $curl = curl_init();
		$curlOpts = array();

		// Headers
		$headers = array('User-Agent: CoinTigerPHP/v1');

		//GET USER APIKEY
		$auth = $this -> _authentication -> getData();

		// Get the authentication class and parse its payload into the HTTP header.

		// HTTP method
		$method = strtolower($method);
		if ($method == 'get' || $method == 'getwithsign') {
			curl_setopt($ch, CURLOPT_HTTPGET, 1);
            if ($params != null) {
                $method == 'getwithsign' && $params = $this->_getArrDataWithSign($auth->apiKeySecret, $params);
                $queryString = http_build_query($params);
				$url .= "?" . $queryString;
			}
		} else if ($method == 'post') {
			$authenticationClass = get_class($this -> _authentication);

			switch ($authenticationClass) {

				case 'CoinTiger_ApiKeyAuthentication' :
					$params = $this->_getArrDataWithSign($auth->apiKeySecret, $params);
					break;
				default :
					throw new CoinTiger_Exception("Invalid authentication mechanism");
					break;
			}

			curl_setopt($ch, CURLOPT_POST, 1);
			// $curlOpts[CURLOPT_POST] = 1;

			// Create query string
			curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));

			// $curlOpts[CURLOPT_POSTFIELDS] = json_encode($params);
			//$params;
		}

		// CURL options
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);

		// $curlOpts[CURLOPT_URL] = $url;
		// $curlOpts[CURLOPT_HTTPHEADER] = $headers;
		// $curlOpts[CURLOPT_SSL_VERIFYHOST] = FALSE;
		// $curlOpts[CURLOPT_SSL_VERIFYPEER] = FALSE;

		// curl_setopt_array($curl, $curlOpts);

		// Do request
		$response = $this -> _requestor -> doCurlRequest($ch);
		// Decode response
		try {
			$body = $response['body'];
			$json = json_decode($body);
		} catch (Exception $e) {
			echo "Invalid response body" . $response['statusCode'] . $response['body'];
		}
		if ($json === null) {
			echo "Invalid response body" . $response['statusCode'] . $response['body'];
		}
		if (isset($json -> error)) {
			throw new CoinTiger_Exception($json -> error, $response['statusCode'], $response['body']);
		} else if (isset($json -> errors)) {
			throw new CoinTiger_Exception(implode($json -> errors, ', '), $response['statusCode'], $response['body']);
		}

		return $json;
	}

    //CoinTiger 请求加密流程
	private function _getArrDataWithSign($apiKeySecret, $params)
    {
        ksort($params);
        $sign = "";
        while ($key = key($params)) {
            $sign .= $key . $params[$key];
            next($params);
        }
        $sign = $sign . $apiKeySecret;
        $sign = str_replace(' ', '', $sign);
        $sign = hash_hmac('sha512', $sign, $apiKeySecret);
        $params['sign'] = $sign;
        return $params;
    }

}
